// Locadora de Filmes - constraints do Neo4j (grafo de recomendação)

CREATE CONSTRAINT usuario_login IF NOT EXISTS
FOR (u:Usuario) REQUIRE u.login IS UNIQUE;

CREATE CONSTRAINT filme_id IF NOT EXISTS
FOR (f:Filme) REQUIRE f.id IS UNIQUE;

CREATE CONSTRAINT genero_nome IF NOT EXISTS
FOR (g:Genero) REQUIRE g.nome IS UNIQUE;
