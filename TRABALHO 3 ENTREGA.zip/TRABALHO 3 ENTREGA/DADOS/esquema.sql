DROP TABLE IF EXISTS avaliacoes CASCADE;
DROP TABLE IF EXISTS alugueis CASCADE;
DROP TABLE IF EXISTS filme_genero CASCADE;
DROP TABLE IF EXISTS filmes CASCADE;
DROP TABLE IF EXISTS generos CASCADE;

CREATE TABLE IF NOT EXISTS usuarios (
    login      VARCHAR(50)  PRIMARY KEY,
    senha_hash VARCHAR(255) NOT NULL,
    tipo       VARCHAR(10)  NOT NULL CHECK (tipo IN ('Admin', 'Usuario'))
);

CREATE TABLE generos (
    id   SERIAL PRIMARY KEY,
    nome VARCHAR(50) NOT NULL UNIQUE
);

-- id é o uuid hex (32 caracteres) que o models.py já gera
CREATE TABLE filmes (
    id        VARCHAR(32)  PRIMARY KEY,
    titulo    VARCHAR(200) NOT NULL,
    genero_id INT          NOT NULL REFERENCES generos(id),
    sinopse TEXT NOT NULL DEFAULT '',
    copias    INT          NOT NULL DEFAULT 1 CHECK (copias >= 1)
);

-- Aluguel ativo = data_devolucao IS NULL. Também serve de histórico.
CREATE TABLE alugueis (
    id             SERIAL PRIMARY KEY,
    usuario        VARCHAR(50)  NOT NULL REFERENCES usuarios(login),
    filme_id       VARCHAR(32)  REFERENCES filmes(id) ON DELETE SET NULL,
    filme_titulo   VARCHAR(200) NOT NULL,
    data_aluguel   TIMESTAMP    NOT NULL DEFAULT NOW(),
    data_devolucao TIMESTAMP
);

-- Um filme só pode ter um aluguel ativo por vez
CREATE UNIQUE INDEX ux_aluguel_ativo
    ON alugueis (usuario, filme_id) WHERE data_devolucao IS NULL;

CREATE TABLE avaliacoes (
    id         SERIAL PRIMARY KEY,
    usuario    VARCHAR(50) NOT NULL REFERENCES usuarios(login),
    filme_id   VARCHAR(32) NOT NULL REFERENCES filmes(id) ON DELETE CASCADE,
    nota       INT         NOT NULL CHECK (nota BETWEEN 1 AND 5),
    comentario TEXT,
    data_hora  TIMESTAMP   NOT NULL DEFAULT NOW(),
    UNIQUE (usuario, filme_id)
);